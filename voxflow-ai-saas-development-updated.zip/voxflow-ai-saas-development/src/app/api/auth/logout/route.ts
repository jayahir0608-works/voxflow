import { NextResponse } from "next/server";
import { assertSameOrigin, clearSession } from "@/lib/auth";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  await clearSession();
  return NextResponse.json({ ok: true });
}
