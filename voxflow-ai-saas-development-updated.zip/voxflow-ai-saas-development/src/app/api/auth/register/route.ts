import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { allowRequest, assertSameOrigin, createSession, hashPassword, requestAddress, safeUser } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  if (!allowRequest(`register:${requestAddress(request)}`, 8, 60 * 60 * 1000)) {
    return NextResponse.json({ error: "Too many account attempts. Please try again later." }, { status: 429 });
  }
  let body: { email?: string; password?: string; name?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 320) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  if (!name || name.length < 2) return NextResponse.json({ error: "Enter a name with at least 2 characters." }, { status: 400 });
  if (password.length < 10 || password.length > 128 || !/[a-z]/i.test(password) || !/\d/.test(password)) {
    return NextResponse.json({ error: "Use a password with at least 10 characters and one number." }, { status: 400 });
  }
  try {
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
    const [user] = await db.insert(users).values({ email, name, passwordHash: await hashPassword(password) }).returning();
    await createSession(user.id);
    return NextResponse.json({ user: safeUser(user) }, { status: 201 });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
    }
    console.error("Account registration failed", error);
    return NextResponse.json({ error: "We couldn't create your account. Please try again." }, { status: 500 });
  }
}
