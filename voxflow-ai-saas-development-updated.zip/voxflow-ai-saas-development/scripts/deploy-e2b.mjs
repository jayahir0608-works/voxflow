// Usage:  E2B_API_KEY=... DATABASE_URL=... OPENAI_API_KEY=... node scripts/deploy-e2b.mjs
// Needs:  npm i -D e2b   (Node 20+)
import { Sandbox } from "e2b";
import { execSync } from "node:child_process";
import { readFileSync } from "node:fs";

const need = (k) => { if (!process.env[k]) { console.error(`Missing ${k}`); process.exit(1); } return process.env[k]; };
need("E2B_API_KEY");
const envs = {
  DATABASE_URL: need("DATABASE_URL"),
  OPENAI_API_KEY: process.env.OPENAI_API_KEY ?? "",
  VOXFLOW_BOOTSTRAP_SECRET: process.env.VOXFLOW_BOOTSTRAP_SECRET ?? "",
  OPENAI_TRANSCRIPTION_MODEL: process.env.OPENAI_TRANSCRIPTION_MODEL ?? "",
  OPENAI_TEXT_MODEL: process.env.OPENAI_TEXT_MODEL ?? "",
  NODE_ENV: "production",
};
for (const k of Object.keys(envs)) if (!envs[k]) delete envs[k];

console.log("Packing project...");
execSync("tar --exclude=node_modules --exclude=.next --exclude=.git --exclude=.env -czf /tmp/voxflow.tgz .", { stdio: "inherit" });
const tgz = readFileSync("/tmp/voxflow.tgz");

console.log("Creating sandbox...");
const sbx = await Sandbox.create({ timeoutMs: 60 * 60 * 1000, envs }); // 1h (raise on a paid plan)
const run = (cmd, opts = {}) => sbx.commands.run(cmd, { cwd: "/home/user/app", timeoutMs: 15 * 60 * 1000, onStdout: (d) => process.stdout.write(d), onStderr: (d) => process.stderr.write(d), ...opts });

await sbx.commands.run("mkdir -p /home/user/app");
await sbx.files.write("/home/user/voxflow.tgz", tgz.buffer.slice(tgz.byteOffset, tgz.byteOffset + tgz.byteLength));
await run("tar -xzf /home/user/voxflow.tgz -C /home/user/app", { cwd: "/home/user" });

// Next 16 needs Node >= 20.9
await run(`node -e "process.exit(+process.versions.node.split('.')[0]>=20?0:1)" || (curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs)`);
await run("npm install --no-audit --no-fund");
await run("npx drizzle-kit push --force");   // creates tables in DATABASE_URL
await run("npm run build");
await sbx.commands.run("npx next start -H 0.0.0.0 -p 3000", { cwd: "/home/user/app", background: true, envs });

console.log(`\nLive: https://${sbx.getHost(3000)}\nSandbox id: ${sbx.sandboxId}`);
