import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { dictations } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to update this dictation." }, { status: 401 });
  const { id } = await params;
  let body: { title?: unknown; rawText?: unknown; finalText?: unknown; mode?: unknown; style?: unknown; language?: unknown; durationSeconds?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const update: Partial<typeof dictations.$inferInsert> = { updatedAt: new Date() };
  if (body.title !== undefined) {
    if (typeof body.title !== "string" || body.title.trim().length === 0 || body.title.length > 160) return NextResponse.json({ error: "Title must be 1–160 characters." }, { status: 400 });
    update.title = body.title.trim();
  }
  if (body.rawText !== undefined) {
    if (typeof body.rawText !== "string" || body.rawText.length > 100_000) return NextResponse.json({ error: "Original text is too long." }, { status: 400 });
    update.rawText = body.rawText;
  }
  if (body.finalText !== undefined) {
    if (typeof body.finalText !== "string" || body.finalText.length > 100_000) return NextResponse.json({ error: "Dictation text is too long." }, { status: 400 });
    update.finalText = body.finalText;
    update.wordCount = body.finalText.trim() ? body.finalText.trim().split(/\s+/u).length : 0;
  }
  if (body.mode === "smart" || body.mode === "verbatim") update.mode = body.mode;
  if (typeof body.style === "string") update.style = body.style.slice(0, 40);
  if (typeof body.language === "string") update.language = body.language.slice(0, 32);
  if (typeof body.durationSeconds === "number" && Number.isFinite(body.durationSeconds)) update.durationSeconds = Math.max(0, Math.min(86_400, Math.round(body.durationSeconds)));

  const [updated] = await db.update(dictations).set(update).where(and(eq(dictations.id, id), eq(dictations.userId, user.id))).returning();
  if (!updated) return NextResponse.json({ error: "Dictation not found." }, { status: 404 });
  return NextResponse.json({ dictation: updated });
}

export async function DELETE(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to delete this dictation." }, { status: 401 });
  const { id } = await params;
  const [removed] = await db.delete(dictations).where(and(eq(dictations.id, id), eq(dictations.userId, user.id))).returning({ id: dictations.id });
  if (!removed) return NextResponse.json({ error: "Dictation not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
