import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { vocabulary } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const { id } = await params;
  let body: { word?: unknown; correction?: unknown; category?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const update: Partial<typeof vocabulary.$inferInsert> = {};
  if (body.word !== undefined) {
    if (typeof body.word !== "string" || !body.word.trim() || body.word.trim().length > 100 || /[\r\n]/.test(body.word)) return NextResponse.json({ error: "Word must be 1–100 characters." }, { status: 400 });
    update.word = body.word.trim();
  }
  if (body.correction !== undefined) {
    if (typeof body.correction !== "string" || body.correction.length > 100 || /[\r\n]/.test(body.correction)) return NextResponse.json({ error: "Correction must be 100 characters or fewer." }, { status: 400 });
    update.correction = body.correction.trim() || null;
  }
  if (body.category !== undefined) {
    if (typeof body.category !== "string" || body.category.length > 40) return NextResponse.json({ error: "Category must be 40 characters or fewer." }, { status: 400 });
    update.category = body.category.trim() || "Custom term";
  }
  try {
    const [item] = await db.update(vocabulary).set(update).where(and(eq(vocabulary.id, id), eq(vocabulary.userId, user.id))).returning();
    if (!item) return NextResponse.json({ error: "Word not found." }, { status: 404 });
    return NextResponse.json({ item });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") return NextResponse.json({ error: "That word is already in your dictionary." }, { status: 409 });
    return NextResponse.json({ error: "We couldn't update that word." }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const { id } = await params;
  const [deleted] = await db.delete(vocabulary).where(and(eq(vocabulary.id, id), eq(vocabulary.userId, user.id))).returning({ id: vocabulary.id });
  if (!deleted) return NextResponse.json({ error: "Word not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
