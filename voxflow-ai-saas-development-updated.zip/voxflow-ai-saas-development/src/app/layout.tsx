import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "VoxFlow AI — Speak Naturally. Write Brilliantly.",
  description: "A private, AI-powered voice writing workspace for your ideas, meetings, and code.",
  applicationName: "VoxFlow AI",
  keywords: ["voice typing", "AI dictation", "speech to text", "multilingual transcription"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
