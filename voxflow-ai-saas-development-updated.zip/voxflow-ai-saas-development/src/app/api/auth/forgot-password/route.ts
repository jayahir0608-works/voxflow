import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { allowRequest, assertSameOrigin, hashToken, requestAddress } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  if (!allowRequest(`forgot:${requestAddress(request)}`, 4, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Please wait before requesting another reset email." }, { status: 429 });
  }
  if (!process.env.RESEND_API_KEY || !process.env.RESEND_FROM_EMAIL) {
    return NextResponse.json({ error: "Password-reset email is not configured. Set RESEND_API_KEY and RESEND_FROM_EMAIL on the server." }, { status: 503 });
  }
  let body: { email?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 320) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  const [user] = await db.select({ id: users.id, email: users.email }).from(users).where(eq(users.email, email)).limit(1);
  if (!user) return NextResponse.json({ message: "If an account exists, a reset link will be on its way." });

  const token = randomBytes(32).toString("hex");
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  await db.delete(passwordResets).where(eq(passwordResets.userId, user.id));
  await db.insert(passwordResets).values({ userId: user.id, tokenHash, expiresAt });

  const baseUrl = (process.env.APP_URL || new URL(request.url).origin).replace(/\/$/, "");
  const resetUrl = `${baseUrl}/reset-password?token=${encodeURIComponent(token)}`;
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.RESEND_FROM_EMAIL,
      to: [user.email],
      subject: "Reset your VoxFlow password",
      text: `Use this one-time link to reset your VoxFlow password. It expires in 30 minutes.\n\n${resetUrl}\n\nIf you did not request this, ignore this email.`,
      html: `<p>Use this one-time link to reset your VoxFlow password. It expires in 30 minutes.</p><p><a href="${resetUrl}">Reset your password</a></p><p>If you did not request this, ignore this email.</p>`,
    }),
    signal: AbortSignal.timeout(15_000),
  }).catch(() => null);
  if (!response?.ok) {
    await db.delete(passwordResets).where(eq(passwordResets.tokenHash, tokenHash));
    console.error("Password reset email delivery failed", response?.status || "network error");
  }
  return NextResponse.json({ message: "If an account exists, a reset link will be on its way." });
}
