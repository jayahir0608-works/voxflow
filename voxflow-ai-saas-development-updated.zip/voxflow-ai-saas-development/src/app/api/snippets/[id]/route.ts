import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { snippets } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const { id } = await params;
  let body: { name?: unknown; triggerPhrase?: unknown; expansion?: unknown; category?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const update: Partial<typeof snippets.$inferInsert> = { updatedAt: new Date() };
  for (const field of ["name", "triggerPhrase", "expansion", "category"] as const) {
    const value = body[field];
    if (value === undefined) continue;
    const limit = field === "expansion" ? 10_000 : field === "category" ? 40 : 100;
    if (typeof value !== "string" || !value.trim() || value.trim().length > limit) {
      return NextResponse.json({ error: `${field === "triggerPhrase" ? "Trigger phrase" : field[0].toUpperCase() + field.slice(1)} must be 1–${limit} characters.` }, { status: 400 });
    }
    update[field] = value.trim();
  }
  try {
    const [item] = await db.update(snippets).set(update).where(and(eq(snippets.id, id), eq(snippets.userId, user.id))).returning();
    if (!item) return NextResponse.json({ error: "Snippet not found." }, { status: 404 });
    return NextResponse.json({ item });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") return NextResponse.json({ error: "That trigger phrase is already in use." }, { status: 409 });
    return NextResponse.json({ error: "We couldn't update that snippet." }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: Context) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const { id } = await params;
  const [deleted] = await db.delete(snippets).where(and(eq(snippets.id, id), eq(snippets.userId, user.id))).returning({ id: snippets.id });
  if (!deleted) return NextResponse.json({ error: "Snippet not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
