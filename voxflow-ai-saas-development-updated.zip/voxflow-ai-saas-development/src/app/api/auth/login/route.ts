import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { allowRequest, assertSameOrigin, createSession, requestAddress, safeUser, verifyPassword } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  if (!allowRequest(`login:${requestAddress(request)}`, 12, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Too many attempts. Please wait a few minutes and try again." }, { status: 429 });
  }
  let body: { email?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!email || !password || email.length > 320 || password.length > 128) {
    return NextResponse.json({ error: "Email or password is incorrect." }, { status: 401 });
  }
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const valid = user ? await verifyPassword(password, user.passwordHash) : false;
  if (!user || !valid) return NextResponse.json({ error: "Email or password is incorrect." }, { status: 401 });
  try {
    await createSession(user.id);
    return NextResponse.json({ user: safeUser(user) });
  } catch (error) {
    console.error("Session creation failed", error);
    return NextResponse.json({ error: "We couldn't start your session. Please try again." }, { status: 500 });
  }
}
