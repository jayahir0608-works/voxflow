"use client";

import { ArrowRight, AudioLines, Check, LockKeyhole, ShieldCheck } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";

export default function ResetPasswordForm() {
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setToken(new URLSearchParams(window.location.search).get("token") || "");
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (password !== confirm) { setError("The passwords don't match."); return; }
    if (!token) { setError("This reset link is missing its token. Request a new one from the sign-in screen."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ token, password }),
      });
      const result = await response.json().catch(() => ({})) as { error?: string; message?: string };
      if (!response.ok) throw new Error(result.error || "Couldn't reset your password.");
      setSuccess(result.message || "Your password has been updated.");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Couldn't reset your password.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="reset-page">
      <section className="reset-card">
        <div className="brand-lockup"><span className="brand-mark"><AudioLines size={19} /></span><div><div className="brand-name">voxflow<span style={{ color: "#ae96f2" }}>.</span></div><div className="brand-caption">AI voice workspace</div></div></div>
        <h1>{success ? "You're all set." : "Choose a new password"}</h1>
        <p>{success ? "Your password has been securely updated. Sign in to pick up where you left off." : "Choose a strong password to secure your VoxFlow account."}</p>
        {success ? <><div className="status-box success" style={{ margin: "18px 0" }}><Check size={15} /><span>{success}</span></div><a className="btn btn-primary" style={{ width: "100%", textDecoration: "none" }} href="/">Return to sign in <ArrowRight size={14} /></a></> : <form onSubmit={submit}>
          <div className="field"><label htmlFor="new-password">New password</label><input id="new-password" type="password" autoComplete="new-password" minLength={10} maxLength={128} required value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 10 characters and one number" /><span className="field-hint">Use at least 10 characters, including one number.</span></div>
          <div className="field"><label htmlFor="confirm-password">Confirm password</label><input id="confirm-password" type="password" autoComplete="new-password" minLength={10} maxLength={128} required value={confirm} onChange={(event) => setConfirm(event.target.value)} placeholder="Type your new password again" /></div>
          {error && <div className="auth-error" role="alert">{error}</div>}
          <button className="btn btn-primary" style={{ width: "100%", marginTop: 19 }} type="submit" disabled={busy || !token}>{busy ? <span className="spinner" /> : <LockKeyhole size={14} />}{busy ? "Updating…" : "Update password"}<ArrowRight size={14} /></button>
          <div className="auth-secure"><ShieldCheck size={12} /> One-time secure reset link</div>
        </form>}
      </section>
    </main>
  );
}
