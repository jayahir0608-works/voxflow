import { and, eq, gt } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { passwordResets, sessions, users } from "@/db/schema";
import { allowRequest, assertSameOrigin, clearSession, hashPassword, hashToken, isStrongPassword, requestAddress } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  if (!allowRequest(`reset:${requestAddress(request)}`, 8, 15 * 60 * 1000)) {
    return NextResponse.json({ error: "Too many attempts. Please request a new reset link later." }, { status: 429 });
  }
  let body: { token?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const token = typeof body.token === "string" ? body.token : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!/^[a-f0-9]{64}$/.test(token)) return NextResponse.json({ error: "This reset link is invalid or has expired." }, { status: 400 });
  if (!isStrongPassword(password)) return NextResponse.json({ error: "Use a password with at least 10 characters and one number." }, { status: 400 });

  const tokenHash = hashToken(token);
  const passwordHash = await hashPassword(password);
  const consumed = await db.transaction(async (tx) => {
    const [reset] = await tx.delete(passwordResets)
      .where(and(eq(passwordResets.tokenHash, tokenHash), gt(passwordResets.expiresAt, new Date())))
      .returning({ userId: passwordResets.userId });
    if (!reset) return false;
    await tx.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, reset.userId));
    await tx.delete(passwordResets).where(eq(passwordResets.userId, reset.userId));
    await tx.delete(sessions).where(eq(sessions.userId, reset.userId));
    return true;
  });
  if (!consumed) return NextResponse.json({ error: "This reset link is invalid or has expired." }, { status: 400 });
  await clearSession();
  return NextResponse.json({ message: "Your password has been updated. You can sign in now." });
}
