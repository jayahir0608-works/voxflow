import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { assertSameOrigin, clearSession, getCurrentUser, safeUser, verifyPassword } from "@/lib/auth";
import type { WritingStyle } from "@/lib/providers";

const styles: WritingStyle[] = ["Natural", "Professional", "Formal", "Casual", "Friendly", "Academic", "Business", "Email", "Social Media", "Technical", "Developer / Coding"];
const languages = ["auto", "en-IN", "en-US", "hi-IN", "gu-IN", "hinglish"];

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Your session has expired. Please sign in again.", code: "session_expired" }, { status: 401 });
  return NextResponse.json({ user: safeUser(user) }, { headers: { "Cache-Control": "no-store" } });
}

export async function PATCH(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Your session has expired. Please sign in again.", code: "session_expired" }, { status: 401 });
  let body: { name?: unknown; language?: unknown; style?: unknown; mode?: unknown; developerMode?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const update: Partial<typeof users.$inferInsert> = { updatedAt: new Date() };
  if (body.name !== undefined) {
    if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
      return NextResponse.json({ error: "Name must be 2–100 characters." }, { status: 400 });
    }
    update.name = body.name.trim();
  }
  if (body.language !== undefined) {
    if (typeof body.language !== "string" || !languages.includes(body.language)) return NextResponse.json({ error: "Choose a supported language." }, { status: 400 });
    update.language = body.language;
  }
  if (body.style !== undefined) {
    if (typeof body.style !== "string" || !styles.includes(body.style as WritingStyle)) return NextResponse.json({ error: "Choose a supported writing style." }, { status: 400 });
    update.style = body.style;
  }
  if (body.mode !== undefined) {
    if (body.mode !== "smart" && body.mode !== "verbatim") return NextResponse.json({ error: "Choose Smart or Verbatim mode." }, { status: 400 });
    update.mode = body.mode;
  }
  if (body.developerMode !== undefined) {
    if (typeof body.developerMode !== "boolean") return NextResponse.json({ error: "Developer mode must be a boolean." }, { status: 400 });
    update.developerMode = body.developerMode;
  }
  const [updated] = await db.update(users).set(update).where(eq(users.id, user.id)).returning();
  return NextResponse.json({ user: safeUser(updated) });
}

export async function DELETE(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  let body: { password?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Confirm your password to delete this account." }, { status: 400 });
  }
  if (typeof body.password !== "string" || !(await verifyPassword(body.password, user.passwordHash))) {
    return NextResponse.json({ error: "Your password is incorrect." }, { status: 401 });
  }
  await db.delete(users).where(eq(users.id, user.id));
  await clearSession();
  return NextResponse.json({ ok: true });
}
