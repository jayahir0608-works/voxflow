import VoxFlowApp from "@/components/voxflow-app";

export default function HomePage() {
  return <VoxFlowApp />;
}
