import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { vocabulary } from "@/db/schema";
import { allowRequest, assertSameOrigin, getCurrentUser } from "@/lib/auth";
import { ProviderError, transcribeAudio } from "@/lib/providers";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to transcribe audio." }, { status: 401 });
  if (!allowRequest(`transcribe:${user.id}`, 20, 60 * 60 * 1000)) {
    return NextResponse.json({ error: "You've reached the transcription limit for this hour. Try again later." }, { status: 429 });
  }
  if (Number(request.headers.get("content-length") || 0) > 26 * 1024 * 1024) {
    return NextResponse.json({ error: "Audio uploads are limited to 25 MB." }, { status: 413 });
  }
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Couldn't read the audio upload." }, { status: 400 });
  }
  const audio = form.get("audio");
  const language = typeof form.get("language") === "string" ? String(form.get("language")) : "auto";
  if (!(audio instanceof File)) return NextResponse.json({ error: "Choose or record an audio file." }, { status: 400 });
  const allowedTypes = ["audio/webm", "audio/webm;codecs=opus", "audio/ogg", "audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp3", "audio/mp4", "audio/x-m4a"];
  if (audio.type && !allowedTypes.some((type) => audio.type.toLowerCase().startsWith(type))) {
    return NextResponse.json({ error: "Use a supported recording format such as WebM, MP3, WAV, M4A, or OGG." }, { status: 415 });
  }
  try {
    const terms = await db.select({ word: vocabulary.word, correction: vocabulary.correction })
      .from(vocabulary).where(eq(vocabulary.userId, user.id)).limit(50);
    const result = await transcribeAudio({ audio, language: ["auto", "en-IN", "en-US", "hi-IN", "gu-IN", "hinglish"].includes(language) ? language : "auto", vocabulary: terms });
    return NextResponse.json(result, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof ProviderError) return NextResponse.json({ error: error.message, code: error.code }, { status: error.status });
    console.error("Transcription request failed", error);
    return NextResponse.json({ error: "Transcription failed. Your draft is still available in the editor." }, { status: 502 });
  }
}
