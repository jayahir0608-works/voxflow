import { NextResponse } from "next/server";
import { getCurrentUser, safeUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  return NextResponse.json({ user: user ? safeUser(user) : null }, { headers: { "Cache-Control": "no-store" } });
}
