import { createHash, timingSafeEqual } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const configuredSecret = process.env.VOXFLOW_BOOTSTRAP_SECRET;
  if (!configuredSecret || configuredSecret.length < 24) {
    return NextResponse.json({ error: "Owner bootstrap is disabled. Configure a 24-character-or-longer VOXFLOW_BOOTSTRAP_SECRET on the server." }, { status: 503 });
  }
  const supplied = request.headers.get("x-bootstrap-secret") || "";
  const suppliedHash = createHash("sha256").update(supplied).digest();
  const configuredHash = createHash("sha256").update(configuredSecret).digest();
  if (!timingSafeEqual(suppliedHash, configuredHash)) return NextResponse.json({ error: "Not authorized." }, { status: 401 });
  let body: { email?: string; name?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 100) : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (process.env.VOXFLOW_BOOTSTRAP_EMAIL && email !== process.env.VOXFLOW_BOOTSTRAP_EMAIL.trim().toLowerCase()) {
    return NextResponse.json({ error: "This email is not allowed to bootstrap the owner account." }, { status: 403 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !name || name.length < 2 || password.length < 10 || password.length > 128 || !/\d/.test(password)) {
    return NextResponse.json({ error: "Provide a valid email, name, and password (10+ characters with a number)." }, { status: 400 });
  }
  try {
    const [owner] = await db.select({ id: users.id }).from(users).where(eq(users.role, "owner")).limit(1);
    if (owner) return NextResponse.json({ error: "An owner account has already been bootstrapped." }, { status: 409 });
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
    const [user] = await db.insert(users).values({ email, name, passwordHash: await hashPassword(password), role: "owner" }).returning({ id: users.id, email: users.email, name: users.name });
    return NextResponse.json({ user, message: "Owner created. Sign in through the VoxFlow login screen." }, { status: 201 });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "An account or owner already exists." }, { status: 409 });
    }
    console.error("Owner bootstrap failed", error);
    return NextResponse.json({ error: "Owner bootstrap failed." }, { status: 500 });
  }
}
