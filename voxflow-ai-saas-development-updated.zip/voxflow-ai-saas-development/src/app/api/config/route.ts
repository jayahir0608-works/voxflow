import { NextResponse } from "next/server";
import { providerStatus } from "@/lib/providers";

export function GET() {
  const status = providerStatus();
  return NextResponse.json({
    providers: {
      transcription: status.transcription,
      cleanup: status.cleanup,
      transcriptionModel: status.transcriptionModel,
      cleanupModel: status.cleanupModel,
    },
    realtime: "browser-speech-recognition-when-supported",
    audioRetention: "disabled",
  }, { headers: { "Cache-Control": "no-store" } });
}
