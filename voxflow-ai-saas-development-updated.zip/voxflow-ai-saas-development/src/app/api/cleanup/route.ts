import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { snippets, vocabulary } from "@/db/schema";
import { allowRequest, assertSameOrigin, getCurrentUser } from "@/lib/auth";
import { cleanTranscript, ProviderError } from "@/lib/providers";
import type { WritingStyle } from "@/lib/providers";

export const runtime = "nodejs";
const styles: WritingStyle[] = ["Natural", "Professional", "Formal", "Casual", "Friendly", "Academic", "Business", "Email", "Social Media", "Technical", "Developer / Coding"];
const languages = ["auto", "en-IN", "en-US", "hi-IN", "gu-IN", "hinglish"];

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to use AI cleanup." }, { status: 401 });
  if (!allowRequest(`cleanup:${user.id}`, 30, 60 * 60 * 1000)) {
    return NextResponse.json({ error: "You've reached the AI cleanup limit for this hour. Try again later." }, { status: 429 });
  }
  let body: { text?: unknown; mode?: unknown; style?: unknown; language?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  if (typeof body.text !== "string") return NextResponse.json({ error: "Text is required." }, { status: 400 });
  const mode = body.mode === "verbatim" ? "verbatim" : "smart";
  const style = typeof body.style === "string" && styles.includes(body.style as WritingStyle) ? body.style as WritingStyle : user.style as WritingStyle;
  const language = typeof body.language === "string" && languages.includes(body.language) ? body.language : user.language;
  try {
    const [terms, savedSnippets] = await Promise.all([
      db.select({ word: vocabulary.word, correction: vocabulary.correction }).from(vocabulary).where(eq(vocabulary.userId, user.id)).limit(100),
      db.select({ triggerPhrase: snippets.triggerPhrase, expansion: snippets.expansion }).from(snippets).where(eq(snippets.userId, user.id)).limit(50),
    ]);
    const text = await cleanTranscript({ text: body.text, mode, style, language, developerMode: user.developerMode, vocabulary: terms, snippets: savedSnippets });
    return NextResponse.json({ text }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof ProviderError) return NextResponse.json({ error: error.message, code: error.code }, { status: error.status });
    console.error("AI cleanup request failed", error);
    return NextResponse.json({ error: "AI cleanup failed. Your original text is unchanged." }, { status: 502 });
  }
}
