import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { snippets } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to view your snippets." }, { status: 401 });
  const items = await db.select().from(snippets).where(eq(snippets.userId, user.id)).orderBy(asc(snippets.name));
  return NextResponse.json({ snippets: items }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to create a snippet." }, { status: 401 });
  let body: { name?: unknown; triggerPhrase?: unknown; expansion?: unknown; category?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const triggerPhrase = typeof body.triggerPhrase === "string" ? body.triggerPhrase.trim() : "";
  const expansion = typeof body.expansion === "string" ? body.expansion.trim() : "";
  const category = typeof body.category === "string" ? body.category.trim().slice(0, 40) : "Personal";
  if (!name || name.length > 100) return NextResponse.json({ error: "Name must be 1–100 characters." }, { status: 400 });
  if (!triggerPhrase || triggerPhrase.length > 100) return NextResponse.json({ error: "Trigger phrase must be 1–100 characters." }, { status: 400 });
  if (!expansion || expansion.length > 10_000) return NextResponse.json({ error: "Expansion must be 1–10,000 characters." }, { status: 400 });
  try {
    const [item] = await db.insert(snippets).values({ userId: user.id, name, triggerPhrase, expansion, category: category || "Personal" }).returning();
    return NextResponse.json({ item }, { status: 201 });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") return NextResponse.json({ error: "That trigger phrase is already in use." }, { status: 409 });
    console.error("Snippet save failed", error);
    return NextResponse.json({ error: "We couldn't save that snippet." }, { status: 500 });
  }
}
