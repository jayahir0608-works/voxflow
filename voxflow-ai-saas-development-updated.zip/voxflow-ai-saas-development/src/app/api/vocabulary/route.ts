import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { vocabulary } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to view your vocabulary." }, { status: 401 });
  const items = await db.select().from(vocabulary).where(eq(vocabulary.userId, user.id)).orderBy(asc(vocabulary.word));
  return NextResponse.json({ vocabulary: items }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to add vocabulary." }, { status: 401 });
  let body: { word?: unknown; correction?: unknown; category?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const word = typeof body.word === "string" ? body.word.trim() : "";
  const correction = typeof body.correction === "string" ? body.correction.trim() : "";
  const category = typeof body.category === "string" ? body.category.trim().slice(0, 40) : "Custom term";
  if (!word || word.length > 100 || /[\r\n]/.test(word)) return NextResponse.json({ error: "Word must be 1–100 characters." }, { status: 400 });
  if (correction.length > 100 || /[\r\n]/.test(correction)) return NextResponse.json({ error: "Correction must be 100 characters or fewer." }, { status: 400 });
  try {
    const [item] = await db.insert(vocabulary).values({ userId: user.id, word, correction: correction || null, category: category || "Custom term" }).returning();
    return NextResponse.json({ item }, { status: 201 });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "23505") return NextResponse.json({ error: "That word is already in your dictionary." }, { status: 409 });
    console.error("Vocabulary save failed", error);
    return NextResponse.json({ error: "We couldn't save that word." }, { status: 500 });
  }
}
