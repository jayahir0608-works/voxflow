import { and, desc, eq, ilike, or, sql, sum } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { dictations } from "@/db/schema";
import { assertSameOrigin, getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

function wordCount(value: string) {
  return value.trim() ? value.trim().split(/\s+/u).length : 0;
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to view your dictations." }, { status: 401 });
  const url = new URL(request.url);
  const search = (url.searchParams.get("q") || "").trim().slice(0, 120).replace(/[\\%_]/g, "\\$&");
  const parsedOffset = Number.parseInt(url.searchParams.get("offset") || "0", 10);
  const offset = Number.isFinite(parsedOffset) ? Math.max(0, Math.min(parsedOffset, 1_000_000)) : 0;
  const filters = [eq(dictations.userId, user.id)];
  if (search) filters.push(or(ilike(dictations.title, `%${search}%`), ilike(dictations.finalText, `%${search}%`), ilike(dictations.rawText, `%${search}%`))!);
  const [items, stats, matches] = await Promise.all([
    db.select({
      id: dictations.id,
      title: dictations.title,
      rawText: dictations.rawText,
      finalText: dictations.finalText,
      mode: dictations.mode,
      style: dictations.style,
      language: dictations.language,
      wordCount: dictations.wordCount,
      durationSeconds: dictations.durationSeconds,
      createdAt: dictations.createdAt,
      updatedAt: dictations.updatedAt,
    }).from(dictations).where(and(...filters)).orderBy(desc(dictations.updatedAt)).limit(50).offset(offset),
    db.select({ total: sql<number>`count(*)`, words: sum(dictations.wordCount), seconds: sum(dictations.durationSeconds) })
      .from(dictations).where(eq(dictations.userId, user.id)),
    db.select({ total: sql<number>`count(*)` }).from(dictations).where(and(...filters)),
  ]);
  return NextResponse.json({
    dictations: items,
    matchCount: Number(matches[0]?.total || 0),
    stats: {
      totalDictations: Number(stats[0]?.total || 0),
      totalWords: Number(stats[0]?.words || 0),
      totalSeconds: Number(stats[0]?.seconds || 0),
    },
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  if (!assertSameOrigin(request)) return NextResponse.json({ error: "Request origin was rejected." }, { status: 403 });
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in before saving a dictation." }, { status: 401 });
  let body: { title?: unknown; rawText?: unknown; finalText?: unknown; mode?: unknown; style?: unknown; language?: unknown; durationSeconds?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  const rawText = typeof body.rawText === "string" ? body.rawText.trim() : "";
  const finalText = typeof body.finalText === "string" ? body.finalText.trim() : "";
  if (!rawText && !finalText) return NextResponse.json({ error: "Add some text before saving." }, { status: 400 });
  if (rawText.length > 100_000 || finalText.length > 100_000) return NextResponse.json({ error: "Dictations may contain up to 100,000 characters." }, { status: 413 });
  const title = typeof body.title === "string" && body.title.trim() ? body.title.trim().slice(0, 160) : (finalText || rawText).split(/[.!?\n]/u)[0]?.slice(0, 80) || "Untitled dictation";
  const mode = body.mode === "verbatim" ? "verbatim" : "smart";
  const style = typeof body.style === "string" ? body.style.slice(0, 40) : user.style;
  const language = typeof body.language === "string" ? body.language.slice(0, 32) : user.language;
  const durationSeconds = typeof body.durationSeconds === "number" && Number.isFinite(body.durationSeconds) ? Math.max(0, Math.min(86_400, Math.round(body.durationSeconds))) : 0;
  const [saved] = await db.insert(dictations).values({
    userId: user.id,
    title,
    rawText,
    finalText: finalText || rawText,
    mode,
    style,
    language,
    wordCount: wordCount(finalText || rawText),
    durationSeconds,
  }).returning();
  return NextResponse.json({ dictation: saved }, { status: 201 });
}
