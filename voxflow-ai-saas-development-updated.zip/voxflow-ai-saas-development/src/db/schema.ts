import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: varchar("email", { length: 320 }).notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    language: varchar("language", { length: 32 }).notNull().default("auto"),
    style: varchar("style", { length: 40 }).notNull().default("Natural"),
    mode: varchar("mode", { length: 24 }).notNull().default("smart"),
    developerMode: boolean("developer_mode").notNull().default(false),
    role: varchar("role", { length: 24 }).notNull().default("user"),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("users_email_unique").on(table.email),
    uniqueIndex("users_single_owner_unique").on(table.role).where(sql`${table.role} = 'owner'`),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: createdAt(),
  },
  (table) => [uniqueIndex("sessions_token_hash_unique").on(table.tokenHash), index("sessions_user_id_idx").on(table.userId)],
);

export const passwordResets = pgTable(
  "password_resets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: createdAt(),
  },
  (table) => [uniqueIndex("password_resets_token_hash_unique").on(table.tokenHash), index("password_resets_user_id_idx").on(table.userId)],
);

export const dictations = pgTable(
  "dictations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 160 }).notNull().default("Untitled dictation"),
    rawText: text("raw_text").notNull().default(""),
    finalText: text("final_text").notNull().default(""),
    mode: varchar("mode", { length: 24 }).notNull().default("smart"),
    style: varchar("style", { length: 40 }).notNull().default("Natural"),
    language: varchar("language", { length: 32 }).notNull().default("auto"),
    wordCount: integer("word_count").notNull().default(0),
    durationSeconds: integer("duration_seconds").notNull().default(0),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("dictations_user_created_idx").on(table.userId, table.createdAt), index("dictations_user_title_idx").on(table.userId, table.title)],
);

export const vocabulary = pgTable(
  "vocabulary",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    word: varchar("word", { length: 100 }).notNull(),
    correction: varchar("correction", { length: 100 }),
    category: varchar("category", { length: 40 }).notNull().default("Custom term"),
    createdAt: createdAt(),
  },
  (table) => [uniqueIndex("vocabulary_user_word_unique").on(table.userId, table.word), index("vocabulary_user_idx").on(table.userId)],
);

export const snippets = pgTable(
  "snippets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    triggerPhrase: varchar("trigger_phrase", { length: 100 }).notNull(),
    expansion: text("expansion").notNull(),
    category: varchar("category", { length: 40 }).notNull().default("Personal"),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("snippets_user_trigger_unique").on(table.userId, table.triggerPhrase), index("snippets_user_idx").on(table.userId)],
);
