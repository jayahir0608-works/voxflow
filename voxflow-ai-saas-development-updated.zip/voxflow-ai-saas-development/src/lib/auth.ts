import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, eq, gt } from "drizzle-orm";
import { cookies, headers } from "next/headers";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";

const scrypt = promisify(scryptCallback);
export const SESSION_COOKIE = "voxflow_session";
const SESSION_DAYS = 30;

export type SafeUser = {
  id: string;
  email: string;
  name: string;
  language: string;
  style: string;
  mode: string;
  developerMode: boolean;
  role: string;
  createdAt: Date;
};

export function safeUser(user: typeof users.$inferSelect): SafeUser {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    language: user.language,
    style: user.style,
    mode: user.mode,
    developerMode: user.developerMode,
    role: user.role,
    createdAt: user.createdAt,
  };
}

export function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const key = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${key.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash || !/^[a-f0-9]{32}$/.test(salt) || !/^[a-f0-9]{128}$/.test(hash)) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = (await scrypt(password, salt, expected.length)) as Buffer;
  return timingSafeEqual(expected, actual);
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ userId, tokenHash: hashToken(token), expiresAt });
  const jar = await cookies();
  // Behind a proxy (e2b, Vercel, etc.) the app sees plain http; trust x-forwarded-proto
  // so the Secure flag matches what the browser actually used.
  const proto = (await headers()).get("x-forwarded-proto")?.split(",")[0]?.trim();
  const secure = proto ? proto === "https" : process.env.NODE_ENV === "production";
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function clearSession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  jar.delete(SESSION_COOKIE);
}

export async function getCurrentUser() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [record] = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return record?.user ?? null;
}

export function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const originHost = new URL(origin).host;
    // Behind a proxy request.url often shows the internal host (localhost:3000),
    // while the browser's Origin is the public one, so accept the forwarded host too.
    const allowed = [
      new URL(request.url).host,
      request.headers.get("host"),
      request.headers.get("x-forwarded-host")?.split(",")[0]?.trim(),
    ].filter(Boolean);
    return allowed.includes(originHost);
  } catch {
    return false;
  }
}

const windows = new Map<string, { start: number; count: number }>();

export function allowRequest(key: string, maxRequests: number, windowMs: number) {
  const now = Date.now();
  const existing = windows.get(key);
  if (!existing || now - existing.start >= windowMs) {
    windows.set(key, { start: now, count: 1 });
    return true;
  }
  existing.count += 1;
  return existing.count <= maxRequests;
}

export function requestAddress(request: Request) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
}

export function isStrongPassword(value: string) {
  return value.length >= 10 && value.length <= 128 && /[a-z]/i.test(value) && /\d/.test(value);
}
